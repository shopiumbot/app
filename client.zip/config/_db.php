<?php

return [
	'dsn' => 'mysql:host=localhost;dbname=',
	'username' => '',
	'password' => '',
	'tablePrefix' => 'prefix_',
];